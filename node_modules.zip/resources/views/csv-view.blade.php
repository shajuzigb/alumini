<table>
    <thead>
        <tr>
            @foreach ($csv->getHeader() as $header)
                <th>{{ $header }}</th>
            @endforeach
        </tr>
    </thead>
    <tbody>
        @foreach ($records as $row)
            <tr>
                @foreach ($row as $column)
                    <td>{{ $column }}</td>
                @endforeach
            </tr>
        @endforeach
    </tbody>
</table>
