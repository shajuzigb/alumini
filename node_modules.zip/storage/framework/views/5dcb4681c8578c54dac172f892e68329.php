<form action="<?php echo e(route('upload.csv')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="file" name="csv_file" accept=".csv">
    <button type="submit">Upload CSV</button>



</form>

<?php /**PATH D:\xampp\htdocs\alumini_ms\resources\views/uploddata.blade.php ENDPATH**/ ?>