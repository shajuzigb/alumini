<link rel="stylesheet" href="<?php echo e(asset('asset/css/table.css')); ?>" />
<p>Resize window to see different layouts.</p>

<div class="list">
  <ul>
  <li> ID</li>
    <li> Name</li>
    <li>User Name</li>
    <li>Email</li>
    <li>Phone</li>
    <li>Edit</li>
    <li>Delete</li>
  </ul>
<?php $__currentLoopData = $var_get_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $var_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <ul>
  <li data-label="id"><?php echo e($var_data['id']); ?></li>
    <li data-label="first name"><?php echo e($var_data['name']); ?></li>
    <li data-label="user name"><?php echo e($var_data['username']); ?></li>
    <li data-label="email"><?php echo e($var_data['email']); ?></li>
    <li data-label="number"><?php echo e($var_data['phone']); ?></li>
    <li><a href="edit/<?php echo e($var_data['id']); ?>">Edit</a></li>
    <li><a href="delete/<?php echo e($var_data['id']); ?>">Delete</a></li>
  </ul>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div><?php /**PATH D:\xampp\htdocs\alumini_ms\resources\views/emp_list.blade.php ENDPATH**/ ?>